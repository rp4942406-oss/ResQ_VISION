(function(){
'use strict';
const KEY='resq_offline_form_draft_v1';
const banner=()=>document.querySelector('#resqOfflineBanner');
function form(){return document.querySelector('#reportForm')||document.querySelector('form[id*="report" i]')}
function saveDraft(){
 const f=form();if(!f)return;
 const out={savedAt:new Date().toISOString(),fields:{}};
 f.querySelectorAll('input,textarea,select').forEach(el=>{
   if(!el.name&& !el.id)return;
   if(el.type==='file')return;
   out.fields[el.name||el.id]={value:el.value||'',checked:!!el.checked};
 });
 try{localStorage.setItem(KEY,JSON.stringify(out));show('Offline: your report text is saved on this device.');}catch(_){}
}
function restoreDraft(){
 const f=form();if(!f)return;
 try{
  const raw=localStorage.getItem(KEY);if(!raw)return;
  const d=JSON.parse(raw);
  Object.entries(d.fields||{}).forEach(([key,v])=>{
   const el=f.querySelector('[name="'+CSS.escape(key)+'"],#'+CSS.escape(key));if(!el)return;
   if(el.type==='checkbox'||el.type==='radio')el.checked=!!v.checked;else if(!el.value)el.value=v.value||'';
  });
  const n=document.createElement('div');n.className='resq-draft-note';n.textContent='Saved offline draft restored. Add any missing photo/location and submit when connected.';
  f.prepend(n);
 }catch(_){}
}
function show(msg){const b=banner();if(!b)return;b.textContent=msg;b.classList.add('show');clearTimeout(window.resqOfflineTimer);window.resqOfflineTimer=setTimeout(()=>b.classList.remove('show'),5000)}
function state(){const b=banner();if(!b)return;if(navigator.onLine){b.classList.remove('show')}else{b.textContent='You are offline. Emergency calls still use your phone network; reports can be saved as drafts.';b.classList.add('show')}}
function install(){
 const b=document.createElement('div');b.id='resqOfflineBanner';b.className='resq-offline-banner';document.body.appendChild(b);
 window.addEventListener('offline',()=>{state();saveDraft()});
 window.addEventListener('online',()=>{state();show('Back online. Review your saved report draft and submit it.')});
 document.addEventListener('submit',e=>{if(!navigator.onLine&&form()===e.target){saveDraft();e.preventDefault();e.stopImmediatePropagation();show('Report saved as an offline draft. Submit it when you reconnect.')}},true);
 document.addEventListener('change',e=>{if(form()&&form().contains(e.target)&&!navigator.onLine)saveDraft()});
 document.addEventListener('click',e=>{const b=e.target.closest?.('[data-page="report"],[data-go="report"]');if(b)setTimeout(restoreDraft,120)});
 state();setTimeout(restoreDraft,500);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
})();