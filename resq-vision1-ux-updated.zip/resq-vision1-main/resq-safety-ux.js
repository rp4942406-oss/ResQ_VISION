/* ResQ-VISION 10/10 usability + emergency access layer */
(function(){
'use strict';
function el(id){return document.getElementById(id)}
function goSafe(page){if(typeof window.go==='function'){window.go(page);closeHub()}}
function toastSafe(msg){if(typeof window.toast==='function')window.toast(msg);else alert(msg)}
function icon(){if(window.lucide)window.lucide.createIcons()}
function closeHub(){const o=el('rqSafetyOverlay');if(o)o.classList.remove('open')}
function openHub(){const o=el('rqSafetyOverlay');if(o){o.classList.add('open');el('rqSafetyClose')?.focus()}}
function call112(){window.location.href='tel:112'}
function makeAction(id,title,desc,iconName,kind,fn){
 const b=document.createElement('button');b.className='rq-action '+(kind||'');b.type='button';b.dataset.rqAction=id;
 b.innerHTML='<span class="ico"><i data-lucide="'+iconName+'"></i></span><span><strong>'+title+'</strong><span>'+desc+'</span></span>';
 b.addEventListener('click',fn);return b;
}
function build(){
 if(el('rqSafetyOverlay'))return;
 const overlay=document.createElement('div');overlay.id='rqSafetyOverlay';overlay.className='rq-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','rqSafetyTitle');
 overlay.innerHTML='<section class="rq-sheet"><div class="rq-sheet-head"><div><h2 id="rqSafetyTitle">Safety Hub</h2><p>Everything important, one or two taps away.</p></div><button id="rqSafetyClose" class="rq-close" aria-label="Close Safety Hub"><i data-lucide="x"></i></button></div><div id="rqActions" class="rq-actions"></div><div class="rq-shortcuts"><button class="rq-chip" data-rq-short="alerts">View alerts</button><button class="rq-chip" data-rq-short="map">Live Goa map</button><button class="rq-chip" data-rq-short="reports">My reports</button><button class="rq-chip" data-rq-short="support">Nearby help</button></div><div class="rq-status"><strong>Emergency:</strong> For immediate danger, injury, fire, entrapment or rescue needs, call <b>112</b>. ResQ-VISION is decision support and does not replace emergency services.</div></section>';
 document.body.appendChild(overlay);
 const box=el('rqActions');
 box.append(
  makeAction('quick','Quick Report','Photo + location + AI-assisted report','camera','',()=>goSafe('report')),
  makeAction('sos','Emergency SOS','Call Goa emergency services','phone-call','danger',call112),
  makeAction('map','Live Risk Map','See active incident and risk areas','map','',()=>goSafe('incidents')),
  makeAction('alerts','Alerts','Official alerts + community signals','bell','',()=>{closeHub();el('noticeBtn')?.click()}),
  makeAction('support','Nearby Help','Police, hospitals, fire & shelters','heart-pulse','',()=>goSafe('support')),
  makeAction('ai','Safety AI','Ask for focused safety guidance','sparkles','ai',()=>goSafe('ai')),
  makeAction('myreports','My Reports','Track submitted reports','clipboard-list','',()=>goSafe('reports')),
  makeAction('details','Detailed Report','Submit more evidence and context','file-text','',()=>goSafe('report'))
 );
 el('rqSafetyClose').addEventListener('click',closeHub);
 overlay.addEventListener('click',e=>{if(e.target===overlay)closeHub()});
 overlay.querySelectorAll('[data-rq-short]').forEach(b=>b.addEventListener('click',()=>{const x=b.dataset.rqShort;if(x==='alerts')el('noticeBtn')?.click();else goSafe({map:'incidents',reports:'reports',support:'support'}[x])}));
 /* Keep one persistent action only: immediate emergency access.
    The Safety Hub remains available from the home screen, avoiding two
    competing floating controls during stressful situations. */
 const bar=document.createElement('div');bar.className='rq-safety-bar';bar.setAttribute('aria-label','Emergency help');
 bar.innerHTML='<strong>Immediate danger?</strong><button class="rq-sos" type="button"><i data-lucide="phone-call"></i> Call 112</button>';
 bar.querySelector('.rq-sos').addEventListener('click',call112);document.body.appendChild(bar);
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeHub();if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openHub()}});
 icon();
}
function enhanceHome(){
 const hero=document.querySelector('#page-home .hero-actions');
 if(hero&&!hero.querySelector('[data-rq-enhanced]')){
  const b=document.createElement('button');b.className='btn btn-light';b.dataset.rqEnhanced='1';b.innerHTML='<i data-lucide="layout-grid"></i> Safety Hub';b.addEventListener('click',openHub);hero.appendChild(b);
 }
}
function announce(){
 const nav=document.querySelector('.mobile-nav');
 if(nav&&!nav.querySelector('[data-rq-enhanced-nav]')){
  const b=document.createElement('button');b.dataset.rqEnhancedNav='1';b.innerHTML='<i data-lucide="layout-grid"></i><span>Hub</span>';b.addEventListener('click',openHub);nav.appendChild(b);icon();
 }
}
function init(){build();enhanceHome();announce();icon()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
window.ResQSafetyHub={open:openHub,close:closeHub,call112:call112};
})();