(function(){
'use strict';
const Q=s=>document.querySelector(s);
const E=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const T=s=>s?new Date(s).toLocaleString():'—';
let ccRows=[], ccResources=[], ccVolunteers=[], ccOfficial=[];
let ccLoaded=false;

function ccRisk(r){
  const p=String(r.priority||'normal').toLowerCase();
  let s=({critical:58,urgent:52,high:38,normal:20,low:8}[p]||15);
  const age=(Date.now()-new Date(r.created_at||Date.now()).getTime())/60000;
  if(age<30)s+=15; else if(age<120)s+=8;
  if(/flood|fire|landslide|cyclone|accident|lightning|drowning|collapse/i.test(String(r.category||'')))s+=12;
  return Math.min(100,Math.round(s));
}
function ccLevel(s){return s>=70?'CRITICAL':s>=40?'HIGH':s>=20?'WATCH':'NORMAL'}
function ccHideOther(){Q('#resqOpsPage')&&(Q('#resqOpsPage').style.display='none');Q('#resqCommandPage')&&(Q('#resqCommandPage').style.display='block');document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));if(Q('#crumb'))Q('#crumb').textContent='AI Command Centre';}
function ccOpen(){if(demoUser?.role!=='admin'){toast?.('Admin sign-in is required');return}ccHideOther();ccLoad();if(window.lucide)lucide.createIcons();}
function ccEnsureNav(){
 if(Q('#resqCmdNav'))return;
 const anchor=Q('#resqOpsNav')||Q('#adminNav'); if(!anchor)return;
 const b=document.createElement('button');b.id='resqCmdNav';b.type='button';b.hidden=true;b.innerHTML='<i data-lucide="command"></i>AI Command Centre';
 anchor.parentNode.insertBefore(b,anchor.nextSibling);b.onclick=ccOpen;
}
function ccEnsurePage(){
 if(Q('#resqCommandPage'))return;
 const main=Q('.main');if(!main)return;
 const s=document.createElement('section');s.id='resqCommandPage';s.className='resq-command-page';s.style.display='none';
 s.innerHTML=
 '<div class="resq-cc-head"><div><div class="eyebrow">Administrator only · Live intelligence</div><h1>AI Safety Command Centre</h1><p>One operational view of live citizen signals, explainable risk, official warnings, resources and volunteer capacity.</p></div><div class="resq-cc-head-actions"><span class="status progress" id="ccLive">Ready</span><button class="btn btn-primary" id="ccRefresh"><i data-lucide="refresh-cw"></i>Refresh all</button></div></div>'+
 '<div class="resq-cc-stats" id="ccStats"></div>'+
 '<div class="resq-cc-grid">'+
 '<section class="resq-cc-card resq-cc-wide"><div class="resq-cc-cardhead"><div><h2>AI situation command</h2><p>Explainable decision support — not an official warning.</p></div></div><div id="ccBrief"></div><div id="ccRecommendations" class="resq-cc-recs"></div></section>'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Why this risk?</h2><p>Visible evidence behind the priority score.</p></div></div><div id="ccEvidence"></div></section>'+
 '</div>'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Live Risk Map</h2><p>Current citizen incident signals grouped by nearby coordinates.</p></div><span class="status progress" id="ccMapCount">0 signals</span></div><div id="ccMap" class="resq-risk-map"></div><div id="ccMapLegend" class="resq-map-legend"></div></section>'+
 '<div class="resq-cc-grid">'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Response resources</h2><p>Capacity available right now.</p></div><button class="btn btn-outline" id="ccOpenResources">Manage</button></div><div id="ccResources"></div></section>'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Volunteer capacity</h2><p>Community responders registered in the system.</p></div><span class="status progress" id="ccVolunteerCount">0</span></div><div id="ccVolunteers"></div></section>'+
 '</div>'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Alert management</h2><p>Official warnings, community signals and AI analysis are kept visibly separate.</p></div></div><div class="resq-alert-columns"><div><div class="resq-alert-label official">OFFICIAL</div><div id="ccOfficial"></div></div><div><div class="resq-alert-label community">COMMUNITY</div><div id="ccCommunity"></div></div><div><div class="resq-alert-label ai">AI SIGNAL</div><div id="ccAISignals"></div></div></div></section>'+
 '<section class="resq-cc-card"><div class="resq-cc-cardhead"><div><h2>Incident analytics</h2><p>Operational trends from the current incident feed.</p></div></div><div id="ccAnalytics"></div></section>';
 main.appendChild(s);
 Q('#ccRefresh').onclick=ccLoad;
 Q('#ccOpenResources').onclick=()=>{Q('#resqCommandPage').style.display='none';window.go?.('resourceHub')};
}
async function ccFetchRows(){
 const {data,error}=await supabaseClient.from('live_incident_reports').select('id,reference_number,category,location_text,latitude,longitude,status,priority,created_at').order('created_at',{ascending:false}).limit(200);
 return {data:data||[],error};
}
async function ccFetchResources(){
 try{const x=await supabaseClient.from('resources').select('id,name,type,location_text,status,quantity,phone').order('created_at',{ascending:false}).limit(100);return x.data||[]}catch(_){return []}
}
async function ccFetchVolunteers(){
 try{const x=await supabaseClient.from('volunteers').select('id,user_id,skills,availability,area,notes,created_at').order('created_at',{ascending:false}).limit(100);return x.data||[]}catch(_){return []}
}
async function ccFetchOfficial(){
 try{const x=await fetch('/api/official-alerts',{cache:'no-store'});if(x.ok){const d=await x.json();return d.alerts||[]}}catch(_){}
 return [];
}
function ccStats(active,resolved){
 const critical=active.filter(r=>r._risk>=70).length, high=active.filter(r=>r._risk>=40&&r._risk<70).length, review=active.filter(r=>/under review|review/i.test(r.status||'')).length;
 const now=Date.now(),h24=active.filter(r=>now-new Date(r.created_at).getTime()<86400000).length;
 const prev24=active.filter(r=>{const a=now-new Date(r.created_at).getTime();return a>=86400000&&a<172800000}).length;
 const trend=prev24?Math.round((h24-prev24)/prev24*100):h24?100:0;
 Q('#ccStats').innerHTML=[
 ['Active incidents',active.length,'activity'],
 ['Critical risk',critical,'alert-triangle'],
 ['High risk',high,'triangle-alert'],
 ['Under review',review,'eye'],
 ['Resolved in feed',resolved,'check-circle-2'],
 ['24h new signals',h24,(trend>=0?'trending-up':'trending-down')]
 ].map(x=>'<div class="resq-cc-stat"><div class="resq-cc-stat-icon"><i data-lucide="'+x[2]+'"></i></div><div><span>'+x[0]+'</span><strong>'+x[1]+'</strong></div></div>').join('');
}
function ccBrief(active){
 const top=active[0];
 if(!top){Q('#ccBrief').innerHTML='<div class="resq-cc-empty">No active citizen incident currently requires operational attention.</div>';Q('#ccRecommendations').innerHTML='';return}
 const official=ccOfficial.length;
 const cats={};active.forEach(r=>cats[r.category||'Other']=(cats[r.category||'Other']||0)+1);
 const topCat=Object.entries(cats).sort((a,b)=>b[1]-a[1])[0];
 const loc=top.location_text||'an unknown area';
 const rec=[];
 if(top._risk>=70)rec.push('Prioritize immediate verification and responder assignment for the highest-risk incident.');
 if(official)rec.push('Cross-check the community signal against '+official+' official safety signal'+(official===1?'':'s')+'.');
 if(topCat)rec.push(topCat[1]+' active signal'+(topCat[1]===1?'':'s')+' are currently classified as '+topCat[0]+'.');
 rec.push('Keep community reports separate from official warnings until verified.');
 Q('#ccBrief').innerHTML='<div class="resq-ai-brief-main"><span class="resq-pill '+(top._risk>=70?'critical':top._risk>=40?'high':'watch')+'">'+top._risk+'/100 · '+ccLevel(top._risk)+'</span><h3>Highest operational priority: '+E(top.category||'Safety incident')+'</h3><p><b>'+E(loc)+'</b> · '+E(top.reference_number||'')+'. The current decision-support score combines priority, recency and hazard signals.</p></div>';
 Q('#ccRecommendations').innerHTML=rec.map(x=>'<div class="resq-cc-rec"><i data-lucide="arrow-right-circle"></i>'+E(x)+'</div>').join('');
}
function ccEvidence(active){
 const top=active[0];if(!top){Q('#ccEvidence').innerHTML='<div class="resq-cc-empty">No evidence yet.</div>';return}
 const p=({critical:35,urgent:30,high:23,normal:12,low:5}[String(top.priority||'normal').toLowerCase()]||8);
 const age=(Date.now()-new Date(top.created_at).getTime())<3600000?15:7;
 const hazard=/flood|fire|landslide|cyclone|accident|lightning|drowning|collapse/i.test(String(top.category||''))?15:7;
 Q('#ccEvidence').innerHTML=[['Incident priority',p],['Recent activity',age],['Hazard severity signal',hazard],['Operational context',Math.max(0,top._risk-p-age-hazard)]].map(x=>'<div class="resq-evidence-row"><span>'+x[0]+'</span><strong>+'+x[1]+'</strong></div>').join('')+'<div class="resq-evidence-total"><span>Total decision-support score</span><strong>'+top._risk+'/100</strong></div><p class="resq-cc-note">This score is decision support only. It does not replace government warnings or emergency-service judgement.</p>';
}
function ccMap(active){
 const valid=active.filter(r=>Number.isFinite(Number(r.latitude))&&Number.isFinite(Number(r.longitude)));
 Q('#ccMapCount').textContent=valid.length+' mapped signal'+(valid.length===1?'':'s');
 if(!valid.length){Q('#ccMap').innerHTML='<div class="resq-cc-empty">No active reports contain coordinates yet.</div>';Q('#ccMapLegend').textContent='Reports with GPS coordinates will appear here.';return}
 const minLat=Math.min(...valid.map(r=>+r.latitude)),maxLat=Math.max(...valid.map(r=>+r.latitude)),minLon=Math.min(...valid.map(r=>+r.longitude)),maxLon=Math.max(...valid.map(r=>+r.longitude));
 const latPad=Math.max(.02,(maxLat-minLat)*.18),lonPad=Math.max(.02,(maxLon-minLon)*.18);
 const clusters={};valid.forEach(r=>{const key=(Math.round(+r.latitude*1000)/1000)+','+(Math.round(+r.longitude*1000)/1000);(clusters[key]??=[]).push(r)});
 Q('#ccMap').innerHTML='<div class="resq-map-grid"></div>'+Object.values(clusters).map(group=>{const r=group.sort((a,b)=>b._risk-a._risk)[0],x=((+r.longitude-(minLon-lonPad))/((maxLon-minLon)+2*lonPad))*100,y=(1-(+r.latitude-(minLat-latPad))/((maxLat-minLat)+2*latPad))*100,s=Math.max(14,Math.min(42,12+group.length*5)),cl=r._risk>=70?'critical':r._risk>=40?'high':'watch';return '<button class="resq-map-node '+cl+'" style="left:'+x+'%;top:'+y+'%;width:'+s+'px;height:'+s+'px" title="'+E(r.location_text||'Incident')+' · '+group.length+' report'+(group.length===1?'':'s')+' · '+r._risk+'/100" data-map-id="'+E(r.id)+'"><span>'+group.length+'</span></button>'}).join('')+'<div class="resq-map-label">Live citizen signals · relative Goa coordinate view</div>';
 Q('#ccMapLegend').innerHTML='<span><i class="dot critical"></i>Critical</span><span><i class="dot high"></i>High</span><span><i class="dot watch"></i>Watch</span><span>Multiple nearby reports are grouped.</span>';
 Q('#ccMap').querySelectorAll('[data-map-id]').forEach(b=>b.onclick=()=>{const r=active.find(x=>String(x.id)===String(b.dataset.mapId));if(r){window.ResQ10X?.detail?.(r.id)}});
}
function renderCCResources(){
 const avail=ccResources.filter(r=>/available/i.test(r.status||'')).length,busy=ccResources.filter(r=>/busy/i.test(r.status||'')).length;
 Q('#ccResources').innerHTML='<div class="resq-mini-stats"><b>'+ccResources.length+'<small>Total</small></b><b>'+avail+'<small>Available</small></b><b>'+busy+'<small>Busy</small></b></div>'+(ccResources.length?ccResources.slice(0,8).map(r=>'<div class="resq-list-row"><span><strong>'+E(r.name)+'</strong><small>'+E(r.type||'Resource')+' · '+E(r.location_text||'')+'</small></span><em class="'+(r.status==='Available'?'ok':r.status==='Busy'?'busy':'off')+'">'+E(r.status||'Unknown')+'</em></div>').join(''):'<div class="resq-cc-empty">No resources found in the connected directory.</div>');
}
function renderCCVolunteers(){
 Q('#ccVolunteerCount').textContent=ccVolunteers.length+' registered';
 Q('#ccVolunteers').innerHTML=ccVolunteers.length?ccVolunteers.slice(0,8).map(v=>'<div class="resq-list-row"><span><strong>'+E(v.skills||'Community support')+'</strong><small>'+E(v.area||'Area not specified')+' · '+E(v.availability||'Availability not specified')+'</small></span><em class="ok">Registered</em></div>').join(''):'<div class="resq-cc-empty">No registered volunteers found.</div>';
}
function ccAlerts(active){
 const community=active.slice(0,6);
 Q('#ccOfficial').innerHTML=ccOfficial.length?ccOfficial.slice(0,5).map(a=>'<div class="resq-alert-item"><strong>'+E(a.title||'Official safety alert')+'</strong><small>'+E(a.source||'Official source')+' · '+E(a.severity||'official')+'</small></div>').join(''):'<div class="resq-cc-empty">No official alerts returned right now.</div>';
 Q('#ccCommunity').innerHTML=community.length?community.map(r=>'<div class="resq-alert-item"><strong>'+E(r.category||'Citizen report')+' · '+E(r.location_text||'Unknown area')+'</strong><small>'+E(r.reference_number||'')+' · '+E(r.status||'Open')+'</small></div>').join(''):'<div class="resq-cc-empty">No active community signals.</div>';
 Q('#ccAISignals').innerHTML=active.slice(0,6).map(r=>'<div class="resq-alert-item"><strong>'+ccLevel(r._risk)+' AI signal · '+r._risk+'/100</strong><small>'+E(r.category||'Incident')+' · '+E(r.location_text||'Unknown area')+'</small></div>').join('')||'<div class="resq-cc-empty">No AI signals.</div>';
}
function ccAnalytics(active,all){
 const now=Date.now(),d7=all.filter(r=>now-new Date(r.created_at).getTime()<604800000).length,d24=all.filter(r=>now-new Date(r.created_at).getTime()<86400000).length;
 const cats={};all.forEach(r=>cats[r.category||'Other']=(cats[r.category||'Other']||0)+1);
 const top=Object.entries(cats).sort((a,b)=>b[1]-a[1]).slice(0,5);
 Q('#ccAnalytics').innerHTML='<div class="resq-analytics-grid"><div><strong>'+d24+'</strong><span>Signals · last 24h</span></div><div><strong>'+d7+'</strong><span>Signals · last 7 days</span></div><div><strong>'+active.length+'</strong><span>Currently active</span></div><div><strong>'+ccResources.filter(r=>r.status==='Available').length+'</strong><span>Resources available</span></div></div><div class="resq-category-bars">'+(top.length?top.map(([k,v])=>'<div><span>'+E(k)+'</span><b><i style="width:'+Math.max(8,Math.round(v/Math.max(...top.map(x=>x[1]))*100))+'%"></i></b><em>'+v+'</em></div>').join(''):'<div class="resq-cc-empty">No category data.</div>')+'</div>';
}
async function ccLoad(){
 if(!demoUser||demoUser.role!=='admin'){toast?.('Admin sign-in is required');return}
 ccEnsurePage();const live=Q('#ccLive');if(live)live.textContent='Updating…';
 const [rows,resources,volunteers,official]=await Promise.all([ccFetchRows(),ccFetchResources(),ccFetchVolunteers(),ccFetchOfficial()]);
 if(rows.error){toast?.('Could not load live incident feed');if(live)live.textContent='Database error';return}
 ccRows=rows.data.map(r=>({...r,_risk:ccRisk(r)}));ccRows.sort((a,b)=>b._risk-a._risk);
 ccResources=resources;ccVolunteers=volunteers;ccOfficial=official;
 const active=ccRows.filter(r=>!['resolved','closed','success'].includes(String(r.status||'').toLowerCase()));
 const resolved=ccRows.length-active.length;
 ccStats(active,resolved);ccBrief(active);ccEvidence(active);ccMap(active);renderCCResources();renderCCVolunteers();ccAlerts(active);ccAnalytics(active,ccRows);
 if(live)live.textContent='Live · '+new Date().toLocaleTimeString();if(window.lucide)lucide.createIcons();ccLoaded=true;
}
function ccInstall(){
 ccEnsureNav();ccEnsurePage();
 const baseGo=window.go;
 window.go=function(page){
   if(page!=='command'&&Q('#resqCommandPage'))Q('#resqCommandPage').style.display='none';
   return baseGo.apply(this,arguments);
 };
 const sync=()=>{const b=Q('#resqCmdNav');if(b)b.hidden=!(demoUser?.role==='admin');};
 sync();setInterval(sync,1500);
 const launch=Q('#page-admin .page-head .resq-cc-launch');if(!launch&&Q('#page-admin .page-head')){const wrap=Q('#page-admin .page-head').lastElementChild;if(wrap){const b=document.createElement('button');b.className='btn btn-primary resq-cc-launch';b.innerHTML='<i data-lucide="command"></i>Open Command Centre';b.onclick=ccOpen;wrap.insertBefore(b,wrap.firstChild);if(window.lucide)lucide.createIcons()}}
 window.ResQCommand={open:ccOpen,refresh:ccLoad};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ccInstall);else ccInstall();
})();