-- Ensure PostgREST can perform the admin operations.
-- RLS remains the security boundary; these grants only make the tables reachable
-- by authenticated users, while the existing admin policies restrict writes.

grant select, insert, update on public.resq_incident_assignments to authenticated;
grant select, insert, update on public.resq_incident_actions to authenticated;
grant select, insert on public.resq_audit_log to authenticated;
