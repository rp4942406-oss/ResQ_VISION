-- ResQ-VISION Admin incident access
-- Allows authenticated admins to operate the existing citizen incident table
-- without changing citizen insert/read behavior.

alter table public.live_incident_reports enable row level security;

drop policy if exists "resq_live_incidents_admin_select" on public.live_incident_reports;
drop policy if exists "resq_live_incidents_admin_update" on public.live_incident_reports;

create policy "resq_live_incidents_admin_select"
on public.live_incident_reports
for select
to authenticated
using (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
);

create policy "resq_live_incidents_admin_update"
on public.live_incident_reports
for update
to authenticated
using (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
)
with check (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
);

-- Verify the expected admin account can be recognized by RLS.
select id, name, role
from public.profiles
where role = 'admin'
order by name;
