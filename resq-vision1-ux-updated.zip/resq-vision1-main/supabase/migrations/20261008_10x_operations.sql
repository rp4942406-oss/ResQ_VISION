-- ResQ-VISION 10/10 Operations Layer
-- Adds operational workflow tables without modifying existing report/auth/storage tables.

create table if not exists public.resq_incident_assignments (
  id uuid primary key default gen_random_uuid(),
  incident_id text not null,
  incident_reference text,
  assignee_user_id uuid references auth.users(id) on delete set null,
  assignee_name text,
  resource_type text,
  status text not null default 'assigned',
  notes text,
  assigned_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.resq_incident_actions (
  id uuid primary key default gen_random_uuid(),
  incident_id text not null,
  incident_reference text,
  action_type text not null,
  action_text text,
  actor_user_id uuid references auth.users(id) on delete set null,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.resq_audit_log (
  id uuid primary key default gen_random_uuid(),
  entity_type text not null,
  entity_id text not null,
  action text not null,
  old_value jsonb default '{}'::jsonb,
  new_value jsonb default '{}'::jsonb,
  actor_user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists resq_assignments_incident_idx on public.resq_incident_assignments(incident_id);
create index if not exists resq_actions_incident_idx on public.resq_incident_actions(incident_id);
create index if not exists resq_audit_entity_idx on public.resq_audit_log(entity_type, entity_id);

alter table public.resq_incident_assignments enable row level security;
alter table public.resq_incident_actions enable row level security;
alter table public.resq_audit_log enable row level security;

drop policy if exists "resq_assignments_admin_select" on public.resq_incident_assignments;
drop policy if exists "resq_assignments_admin_write" on public.resq_incident_assignments;
drop policy if exists "resq_actions_admin_select" on public.resq_incident_actions;
drop policy if exists "resq_actions_admin_write" on public.resq_incident_actions;
drop policy if exists "resq_audit_admin_select" on public.resq_audit_log;
drop policy if exists "resq_audit_admin_write" on public.resq_audit_log;

create policy "resq_assignments_admin_select" on public.resq_incident_assignments
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "resq_assignments_admin_write" on public.resq_incident_assignments
for all to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
) with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

create policy "resq_actions_admin_select" on public.resq_incident_actions
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "resq_actions_admin_write" on public.resq_incident_actions
for all to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
) with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

create policy "resq_audit_admin_select" on public.resq_audit_log
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "resq_audit_admin_write" on public.resq_audit_log
for insert to authenticated with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);

-- Tighten AI persistence: only admins should directly write operational AI assessments.
drop policy if exists "resq_ai_clusters_insert_auth" on public.resq_ai_incident_clusters;
drop policy if exists "resq_ai_assessments_insert_auth" on public.resq_ai_assessments;
drop policy if exists "resq_ai_timeline_insert_auth" on public.resq_ai_timeline;

create policy "resq_ai_clusters_insert_admin" on public.resq_ai_incident_clusters
for insert to authenticated with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "resq_ai_assessments_insert_admin" on public.resq_ai_assessments
for insert to authenticated with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
create policy "resq_ai_timeline_insert_admin" on public.resq_ai_timeline
for insert to authenticated with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
