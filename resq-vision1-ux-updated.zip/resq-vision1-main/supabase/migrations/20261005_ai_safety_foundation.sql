-- ResQ-VISION AI Safety Foundation (additive migration)
-- Does not modify existing reports/auth/storage tables.
create table if not exists public.resq_ai_incident_clusters (
 id uuid primary key default gen_random_uuid(), cluster_key text not null unique, hazard_type text, location_label text,
 confidence numeric(5,2) default 0, status text default 'review', report_count integer default 0,
 evidence jsonb default '{}'::jsonb, created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.resq_ai_assessments (
 id uuid primary key default gen_random_uuid(), assessment_type text not null, risk_score integer default 0,
 verification_score integer default 0, risk_level text default 'normal', summary text, evidence jsonb default '{}'::jsonb,
 model_metadata jsonb default '{}'::jsonb, created_at timestamptz default now()
);
create table if not exists public.resq_ai_timeline (
 id uuid primary key default gen_random_uuid(), cluster_id uuid references public.resq_ai_incident_clusters(id) on delete set null,
 event_type text not null, event_text text, source_type text, source_id text, metadata jsonb default '{}'::jsonb,
 created_at timestamptz default now()
);
create table if not exists public.resq_safety_alerts (
 id uuid primary key default gen_random_uuid(), source_id text not null, source_name text not null, external_id text,
 severity text default 'official', title text not null, summary text, source_url text, issued_at timestamptz,
 payload jsonb default '{}'::jsonb, created_at timestamptz default now(), unique(source_id, external_id)
);
create table if not exists public.resq_notification_subscriptions (
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade, endpoint text,
 subscription jsonb not null, areas jsonb default '[]'::jsonb, enabled boolean default true,
 created_at timestamptz default now(), updated_at timestamptz default now(), unique(user_id, endpoint)
);
alter table public.resq_ai_incident_clusters enable row level security;
alter table public.resq_ai_assessments enable row level security;
alter table public.resq_ai_timeline enable row level security;
alter table public.resq_safety_alerts enable row level security;
alter table public.resq_notification_subscriptions enable row level security;
drop policy if exists "resq_ai_assessments_read_auth" on public.resq_ai_assessments;
create policy "resq_ai_assessments_read_auth" on public.resq_ai_assessments for select to authenticated using (true);
drop policy if exists "resq_ai_clusters_read_auth" on public.resq_ai_incident_clusters;
create policy "resq_ai_clusters_read_auth" on public.resq_ai_incident_clusters for select to authenticated using (true);
drop policy if exists "resq_ai_timeline_read_auth" on public.resq_ai_timeline;
create policy "resq_ai_timeline_read_auth" on public.resq_ai_timeline for select to authenticated using (true);
drop policy if exists "resq_safety_alerts_read_public" on public.resq_safety_alerts;
create policy "resq_safety_alerts_read_public" on public.resq_safety_alerts for select to anon, authenticated using (true);
drop policy if exists "resq_notifications_owner" on public.resq_notification_subscriptions;
create policy "resq_notifications_owner" on public.resq_notification_subscriptions for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);
-- Service-role/backend jobs can write these tables.
