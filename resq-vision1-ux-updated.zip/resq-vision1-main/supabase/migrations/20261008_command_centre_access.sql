-- Admin Command Centre read access.
-- Existing RLS policies remain the security boundary.
grant select on public.resources to authenticated;
grant select on public.volunteers to authenticated;

-- Admin-only read policies for operational directory data.
drop policy if exists "resq_resources_admin_select" on public.resources;
create policy "resq_resources_admin_select" on public.resources
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);

drop policy if exists "resq_volunteers_admin_select" on public.volunteers;
create policy "resq_volunteers_admin_select" on public.volunteers
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id=auth.uid() and p.role='admin')
);
