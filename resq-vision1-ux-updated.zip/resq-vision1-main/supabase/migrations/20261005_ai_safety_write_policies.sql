-- ResQ-VISION AI Safety Center: authenticated write policies
-- Run this AFTER 20261005_ai_safety_foundation.sql.
-- These policies allow signed-in users to persist AI analysis results.
-- Anonymous users remain read-only and existing tables are untouched.

DROP POLICY IF EXISTS "resq_ai_clusters_insert_auth"
ON public.resq_ai_incident_clusters;

CREATE POLICY "resq_ai_clusters_insert_auth"
ON public.resq_ai_incident_clusters
FOR INSERT
TO authenticated
WITH CHECK (TRUE);

DROP POLICY IF EXISTS "resq_ai_assessments_insert_auth"
ON public.resq_ai_assessments;

CREATE POLICY "resq_ai_assessments_insert_auth"
ON public.resq_ai_assessments
FOR INSERT
TO authenticated
WITH CHECK (TRUE);

DROP POLICY IF EXISTS "resq_ai_timeline_insert_auth"
ON public.resq_ai_timeline;

CREATE POLICY "resq_ai_timeline_insert_auth"
ON public.resq_ai_timeline
FOR INSERT
TO authenticated
WITH CHECK (TRUE);
