# ResQ-VISION 10/10 completion checklist

## Already implemented in code
- Operational Response Board with live priority queue.
- Explainable incident risk factors.
- Incident detail + timeline view.
- Incident status actions: responding/review/resolved.
- Responder/resource assignment records.
- Operational audit-log hooks.
- Offline report draft preservation.
- Official alert cache sync endpoint.
- Accessibility/mobile-safe responsive operations UI.

## YOU must do manually in Supabase
1. Open Supabase SQL Editor.
2. Run, in order:
   - supabase/migrations/20261005_ai_safety_foundation.sql
   - supabase/migrations/20261005_ai_safety_write_policies.sql
   - supabase/migrations/20261008_10x_operations.sql
3. Verify the `profiles` table contains the correct `role` values (`admin` for authorized coordinators, `citizen` for normal users).
4. Verify Storage policies and the report bucket size/quota. The app cannot increase your Supabase plan quota from GitHub.
5. Confirm RLS is enabled on all new tables and test an admin and a citizen account separately.

## YOU must do manually in deployment
1. Add server environment variables:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-side only; NEVER put this in index.html)
   - `ALERT_SYNC_TOKEN` (strong random value)
2. Deploy/redeploy after adding them.
3. Keep the service-role key out of GitHub/browser code.

## Scheduled official alerts
The repo now contains:
- functions/api/official-alerts-sync.js
- .github/workflows/resq-official-alert-sync.yml

After deployment:
1. Set GitHub repository secrets:
   - `RESQ_ALERT_SYNC_URL` = your deployed `/api/official-alerts-sync` endpoint.
   - `RESQ_ALERT_SYNC_TOKEN` = the same token configured in deployment.
2. Run the workflow once manually.
3. Confirm `resq_safety_alerts` receives rows.
4. The workflow then refreshes every 10 minutes.

## Real closed-site push notifications
This is the one external service step that cannot safely be completed by editing the repo alone.
For true push notifications while the website is closed, configure a Web Push provider (for example Firebase Cloud Messaging or another Web Push/VAPID service), then connect it to `resq_notification_subscriptions`.
Do NOT put private VAPID/service credentials in frontend JavaScript.

## 10/10 demo data
Before judging, create a small controlled test scenario:
- 6–10 reports in one affected area.
- At least 2 nearby locations.
- Different timestamps so trend/risk is visible.
- One official alert available.
- One incident assigned to a responder.
- One incident moved to Resolved.

Do not present synthetic data as real emergency information. Label a judge demo dataset clearly as a demo/test scenario.

## Judge demo flow
Citizen → Quick Report → AI classification → Supabase → AI clustering → risk score → Response Board → assignment → response status → timeline → resolution.

## Final manual security checks
- Test citizen cannot access admin navigation.
- Test citizen cannot insert AI operational assessments/clusters/timeline rows.
- Test citizen cannot write audit/assignment/action records.
- Test admin can perform the operational workflow.
- Test signed-out users can still access public safety information and 112.
