# ResQ-VISION AI Safety Foundation

## Accessing the features

### AI Safety Center
Open the left sidebar → **AI Safety Center**.
On mobile, open the menu first. The page provides:
- Multimodal/community signal review
- Verification confidence
- Incident deduplication/clustering
- AI-assisted risk assessment
- AI response coordinator
- Explainability/evidence view
- Situation timeline
- JSON export of the current AI brief

### Safety Intelligence
Tap the **bell** in the top-right.
It checks the official Goa safety endpoint and community signals. Use **Open AI Safety Center** for the full analysis.

### Device alerts
Inside Safety Intelligence, choose **Enable device alerts**. Browser notification permission is required.

## Supabase migration

The additive migration is:
`supabase/migrations/20261005_ai_safety_foundation.sql`

Run it in the Supabase SQL Editor for the project used by ResQ-VISION. It creates only new AI/safety tables and RLS policies; it does not alter existing `reports`, Auth, or Storage tables.

New tables:
- `resq_ai_incident_clusters`
- `resq_ai_assessments`
- `resq_ai_timeline`
- `resq_safety_alerts`
- `resq_notification_subscriptions`

The website is deliberately tolerant if these tables have not been migrated yet: core analysis can fall back to the existing `live_incident_reports`, `reports`, and browser data instead of breaking the existing app.

## What is intentionally not claimed

- AI does not issue government warnings.
- Community reports are not official confirmation.
- Risk scores are decision-support context, not guaranteed disaster predictions.
- The browser notification implementation is not yet a 24/7 independent push service. A Cloudflare scheduled job plus Web Push subscription storage is still required for notifications while the site is completely closed.

## Validation

The latest implementation was checked by compiling every inline JavaScript block with `new Function()`. All inline scripts passed syntax validation after the AI Safety Center changes.
