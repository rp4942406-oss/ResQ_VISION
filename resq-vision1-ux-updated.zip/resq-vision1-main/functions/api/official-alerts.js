const SOURCES = {
  sdma: {
    id: 'sdma',
    name: 'Goa State Disaster Management Authority',
    short: 'Goa SDMA',
    url: 'https://www.sdma.goa.gov.in/',
    priority: 100
  },
  imd: {
    id: 'imd',
    name: 'India Meteorological Department · Met Centre Goa',
    short: 'IMD Goa',
    url: 'https://mausam.imd.gov.in/goa/',
    warningUrl: 'https://mausam.imd.gov.in/imd_latest/contents/subdivisionwise-warning_mc.php?id=19',
    priority: 100
  },
  dfes: {
    id: 'dfes',
    name: 'Goa Directorate of Fire & Emergency Services',
    short: 'Goa Fire & Emergency',
    url: 'https://dfes.goa.gov.in/disaster-management/live-calls/',
    priority: 95
  },
  goagov: {
    id: 'goagov',
    name: 'Government of Goa · Notifications',
    short: 'Government of Goa',
    url: 'https://www.goa.gov.in/government/notifications-notices/',
    priority: 85
  },
  incois: {
    id: 'incois',
    name: 'Indian National Centre for Ocean Information Services',
    short: 'INCOIS',
    url: 'https://tsunami.incois.gov.in/',
    priority: 90
  }
};

const naturalHazardWords = /cyclone|storm|thunder|lightning|heavy rain|rainfall|flood|landslide|heat wave|heatwave|drought|earthquake|tsunami|coastal|swell|high wave|warning|alert|advisory|drowning|fire/i;

function cleanText(html) {
  return html.replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&#39;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

function absoluteUrl(href, base) {
  try { return new URL(href, base).toString(); } catch (_) { return base; }
}

function extractLinks(html, base, limit = 8) {
  const out = [];
  const re = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < limit * 4) {
    const text = cleanText(m[2]);
    if (!text || text.length < 8 || text.length > 240) continue;
    const url = absoluteUrl(m[1], base);
    if (url.startsWith('javascript:') || /^(#|mailto:)/i.test(m[1])) continue;
    out.push({ title: text, url });
  }
  return out;
}

function severityFor(text, official = false) {
  const t = text.toLowerCase();
  if (/red alert|warning|critical|severe|extreme|cyclone|tsunami|earthquake/.test(t)) return 'critical';
  if (/orange|heavy rain|landslide|flood|heat wave|thunderstorm|lightning|high wave|storm/.test(t)) return 'elevated';
  if (/yellow|watch|advisory/.test(t)) return 'watch';
  return official ? 'official' : 'watch';
}

async function fetchText(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 9000);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'ResQ-VISION Safety Intelligence/1.0' }
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

async function buildImdAlert() {
  const s = SOURCES.imd;
  try {
    const html = await fetchText(s.warningUrl);
    const text = cleanText(html);
    const start = text.toLowerCase().indexOf('warnings for konkan & goa');
    const block = start >= 0 ? text.slice(start, start + 1800) : text.slice(0, 1800);
    const issue = (block.match(/date of issue:\s*([^|]+?)(?:day 1|$)/i) || [])[1]?.trim() || '';
    const dayMatches = [...block.matchAll(/day\s*([1-7])\s*:\s*([^|]+?)\s*\|\s*/gi)];
    const warnings = [];
    for (let i = 0; i < dayMatches.length; i++) {
      const m = dayMatches[i];
      const next = dayMatches[i + 1];
      const condition = block.slice(m.index + m[0].length, next ? next.index : block.length).replace(/\s+/g, ' ').trim();
      const day = m[1];
      const date = m[2].trim();
      if (!condition || /^no warning$/i.test(condition)) continue;
      warnings.push({ day, date, condition });
    }
    const all = warnings.map(w => w.condition).join('; ');
    if (!warnings.length) {
      return {
        id: 'imd-no-warning',
        sourceId: s.id,
        source: s.name,
        sourceType: 'official',
        severity: 'official',
        title: 'IMD Goa: No active subdivision warning detected',
        summary: issue ? 'The latest IMD Konkan & Goa warning page reports no active warning in the parsed day-by-day entries.' : 'No active IMD warning was detected in the parsed Goa warning page.',
        issuedAt: new Date().toISOString(),
        url: s.warningUrl,
        official: true
      };
    }
    return {
      id: 'imd-warning',
      sourceId: s.id,
      source: s.name,
      sourceType: 'official',
      severity: severityFor(all, true),
      title: 'IMD Goa weather warning',
      summary: (issue ? issue + '. ' : '') + warnings.map(w => 'Day ' + w.day + ': ' + w.date + ' — ' + w.condition).join(' · '),
      issuedAt: new Date().toISOString(),
      url: s.warningUrl,
      official: true
    };
  } catch (error) {
    return { id: 'imd-unavailable', sourceId: s.id, source: s.name, sourceType: 'official', severity: 'official', title: 'IMD Goa source temporarily unavailable', summary: 'Open the official IMD Goa warning page for the latest authoritative warning.', issuedAt: new Date().toISOString(), url: s.warningUrl, official: true, error: true };
  }
}

async function buildSdmaAlerts() {
  const s = SOURCES.sdma;
  try {
    const html = await fetchText(s.url);
    const links = extractLinks(html, s.url, 14)
      .filter(x => naturalHazardWords.test(x.title))
      .slice(0, 6);
    return links.map((x, i) => ({
      id: 'sdma-' + i + '-' + encodeURIComponent(x.title).slice(0, 24),
      sourceId: s.id,
      source: s.name,
      sourceType: 'official',
      severity: severityFor(x.title, true),
      title: x.title,
      summary: 'Published on the official Goa SDMA website. Open the source for the full advisory or notice.',
      issuedAt: new Date().toISOString(),
      url: x.url,
      official: true
    }));
  } catch (error) {
    return [{
      id: 'sdma-unavailable',
      sourceId: s.id,
      source: s.name,
      sourceType: 'official',
      severity: 'official',
      title: 'Goa SDMA source temporarily unavailable',
      summary: 'Open the official Goa SDMA website for the latest disaster-management advisories.',
      issuedAt: new Date().toISOString(),
      url: s.url,
      official: true,
      error: true
    }];
  }
}

async function buildGoaGovAlerts() {
  const s = SOURCES.goagov;
  try {
    const html = await fetchText(s.url);
    const links = extractLinks(html, s.url, 18)
      .filter(x => naturalHazardWords.test(x.title))
      .slice(0, 5);
    return links.map((x, i) => ({
      id: 'goagov-' + i + '-' + encodeURIComponent(x.title).slice(0, 24),
      sourceId: s.id,
      source: s.name,
      sourceType: 'official',
      severity: severityFor(x.title, true),
      title: x.title,
      summary: 'Official Government of Goa notification/notice relevant to safety or hazards.',
      issuedAt: new Date().toISOString(),
      url: x.url,
      official: true
    }));
  } catch (error) {
    return [];
  }
}

async function buildDfesAlert() {
  const s = SOURCES.dfes;
  return {
    id: 'dfes-live',
    sourceId: s.id,
    source: s.name,
    sourceType: 'official',
    severity: 'official',
    title: 'Goa Fire & Emergency Services live incident channel',
    summary: 'The official DFES site publishes real-time incident information including fires, accidents and rescue operations. ResQ-VISION links to the source rather than treating unverified community reports as official.',
    issuedAt: new Date().toISOString(),
    url: s.url,
    official: true
  };
}

export async function onRequestGet() {
  const [imd, sdma, goagov, dfes] = await Promise.all([
    buildImdAlert(),
    buildSdmaAlerts(),
    buildGoaGovAlerts(),
    buildDfesAlert()
  ]);
  const alerts = [imd, ...sdma, ...goagov, dfes]
    .sort((a, b) => ({critical:4,elevated:3,watch:2,official:1}[b.severity] || 0) - ({critical:4,elevated:3,watch:2,official:1}[a.severity] || 0))
    .slice(0, 14);
  return new Response(JSON.stringify({
    ok: true,
    generatedAt: new Date().toISOString(),
    geography: 'Goa, India',
    alerts,
    sources: Object.values(SOURCES)
  }), {
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'public, max-age=300, s-maxage=300'
    }
  });
}
