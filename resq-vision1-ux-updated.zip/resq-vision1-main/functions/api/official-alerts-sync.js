import { onRequestGet as getOfficialAlerts } from './official-alerts.js';

// Cloudflare Pages Function: scheduled official-alert cache refresh.
// Protect this endpoint with ALERT_SYNC_TOKEN and call it from a scheduler.
export async function onRequestGet({ request, env }) {
  try {
    const token = (request.headers.get('x-resq-sync-token') || '').trim();
    const configuredToken = (env.ALERT_SYNC_TOKEN || '').trim();

    if (!configuredToken) {
      return json({ok:false,error:'ALERT_SYNC_TOKEN is missing from this Cloudflare environment'},500);
    }
    if (!token || token !== configuredToken) {
      return json({ok:false,error:'ALERT_SYNC_TOKEN does not match the GitHub Actions token'},401);
    }

    // Call the official-alerts function directly instead of fetching the same
    // Pages deployment over HTTP. This avoids a same-Worker recursive fetch.
    const source = await getOfficialAlerts({
      request: new Request(request.url, {
        method: 'GET',
        headers: { 'accept': 'application/json' }
      }),
      env
    });

    if (!source.ok) {
      return json({ok:false,error:'Official alert source unavailable',status:source.status},502);
    }

    const body = await source.json();
    const alerts = Array.isArray(body.alerts) ? body.alerts : [];

    if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
      return json({ok:false,error:'Supabase sync environment variables are missing'},500);
    }

    // Supabase URLs normally include https://. Normalize the value here so
    // the scheduler also works if the Cloudflare variable was saved without
    // the protocol.
    const supabaseUrl = normalizeSupabaseUrl(env.SUPABASE_URL);

    const rows = alerts.map(a => ({
      source_id: a.sourceId || 'unknown',
      source_name: a.source || 'Official source',
      external_id: a.id || null,
      severity: a.severity || 'official',
      title: a.title || 'Safety alert',
      summary: a.summary || null,
      source_url: a.url || null,
      issued_at: a.issuedAt || new Date().toISOString(),
      payload: a
    }));

    if (rows.length) {
      const res = await fetch(
        supabaseUrl + '/rest/v1/resq_safety_alerts?on_conflict=source_id,external_id',
        {
          method: 'POST',
          headers: {
            'apikey': env.SUPABASE_SERVICE_ROLE_KEY,
            'Authorization': 'Bearer ' + env.SUPABASE_SERVICE_ROLE_KEY,
            'Content-Type': 'application/json',
            'Prefer': 'resolution=merge-duplicates,return=minimal'
          },
          body: JSON.stringify(rows)
        }
      );

      if (!res.ok) {
        const details = await res.text().catch(() => '');
        return json({
          ok:false,
          error:'Supabase alert cache write failed',
          status:res.status,
          details:details.slice(0,300)
        },502);
      }
    }

    return json({
      ok:true,
      stored:rows.length,
      generatedAt:new Date().toISOString()
    },200);
  } catch (error) {
    return json({
      ok:false,
      error:'Alert sync runtime exception',
      details:String(error?.message || error).slice(0,300)
    },500);
  }
}

function normalizeSupabaseUrl(value) {
  let url = String(value || '').trim();

  // Remove accidental surrounding quotes.
  url = url.replace(/^['"]|['"]$/g, '');

  // Add the required URL scheme when it was omitted.
  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }

  return url.replace(/\/+$/, '');
}

function json(payload, status=200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {'content-type':'application/json; charset=utf-8'}
  });
}
