(function(){
'use strict';
const esc=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const q=s=>document.querySelector(s);
const time=s=>s?new Date(s).toLocaleString():'—';
let opsRows=[];

function riskFor(r){
 const age=Math.max(0,(Date.now()-new Date(r.created_at||Date.now()).getTime())/60000);
 let score=25;
 const p=String(r.priority||'normal').toLowerCase();
 score += ({critical:55,urgent:48,high:35,normal:18,low:5}[p]||10);
 if(age<30) score+=12; else if(age<120) score+=6;
 if(/flood|fire|landslide|cyclone|accident|lightning|drowning/i.test(String(r.category||r.description||''))) score+=8;
 return Math.min(100,Math.round(score));
}
function level(s){return s>=70?'critical':s>=40?'high':s>=15?'watch':'normal'}
function factors(r){
 const countFactor=Math.min(30,Math.max(5,Number(r.report_count||1)*5));
 const priority=({critical:35,urgent:30,high:23,normal:12,low:5}[String(r.priority||'normal').toLowerCase()]||8);
 const recency=(Date.now()-new Date(r.created_at||Date.now()).getTime())<3600000?15:7;
 const severity=/flood|fire|landslide|cyclone|accident|drowning/i.test(String(r.category||r.description||''))?15:7;
 return [{name:'Incident priority',value:priority},{name:'Report/activity signal',value:countFactor},{name:'Recent activity',value:recency},{name:'Hazard severity signal',value:severity}];
}
async function official(){
 try{const x=await fetch('/api/official-alerts',{cache:'no-store'});if(x.ok){const d=await x.json();return d.alerts||[]}}catch(_){}
 return [];
}
function ensureNav(){
 if(q('#resqOpsNav'))return;
 const admin=q('#adminNav'); if(!admin)return;
 const b=document.createElement('button');b.id='resqOpsNav';b.type='button';b.innerHTML='<i data-lucide="list-checks"></i>Response Board';b.hidden=true;
 admin.parentNode.insertBefore(b,admin);
 b.addEventListener('click',()=>openOps());
}
function ensureStyles(){if(!q('#resq10xStyle')){const l=document.createElement('link');l.id='resq10xStyle';l.rel='stylesheet';l.href='resq-10x.css';document.head.appendChild(l)}}
function ensurePage(){
 if(q('#resqOpsPage'))return;
 const main=q('.main');if(!main)return;
 const sec=document.createElement('section');sec.id='resqOpsPage';sec.className='resq-ops-page';sec.style.display='none';
 sec.innerHTML='<div class="resq-ops-head"><div><div class="eyebrow">Emergency operations</div><h1>Response Board</h1><p>AI-assisted priority queue for active citizen incidents. Community signals are not official warnings; verify before public escalation.</p></div><button class="btn btn-outline" id="resqOpsRefresh"><i data-lucide="refresh-cw"></i>Refresh</button></div><div class="resq-ops-stats"><div class="resq-ops-stat"><span>Critical</span><strong id="opsCritical">0</strong></div><div class="resq-ops-stat"><span>High priority</span><strong id="opsHigh">0</strong></div><div class="resq-ops-stat"><span>Needs review</span><strong id="opsReview">0</strong></div><div class="resq-ops-stat"><span>Open incidents</span><strong id="opsOpen">0</strong></div></div><div class="resq-ops-grid"><div class="resq-ops-card"><div class="resq-ops-card-head"><h2>Priority queue</h2><span class="status progress" id="opsStatus">Loading…</span></div><div id="opsQueue"></div></div><div><div class="resq-ops-card"><div class="resq-ops-card-head"><h2>AI situation brief</h2></div><div id="opsBrief" class="resq-brief">Refresh the board to generate a current brief.</div></div><div class="resq-ops-card" style="margin-top:14px"><div class="resq-ops-card-head"><h2>Why this risk?</h2></div><div id="opsFactors"><div class="resq-small">Select an incident.</div></div></div></div></div>';
 main.appendChild(sec);
 q('#resqOpsRefresh').addEventListener('click',loadOps);
}
function hidePages(){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.querySelectorAll('[data-page]').forEach(x=>x.classList.remove('active'))}
function showPage(){hidePages();ensurePage();q('#resqOpsPage').style.display='block';q('#crumb').textContent='Response Board'}
function backToHome(){q('#resqOpsPage').style.display='none'; if(window.go)window.go('admin')}
async function loadOps(){
 if(!supabaseClient||!demoUser||demoUser.role!=='admin'){toast?.('Admin sign-in is required');return}
 const st=q('#opsStatus');st.textContent='Loading…';
 const {data,error}=await supabaseClient.from('live_incident_reports').select('id,reference_number,category,location_text,status,priority,created_at').order('created_at',{ascending:false}).limit(100);
 if(error){st.textContent='Database error';q('#opsQueue').innerHTML='<div class="empty"><h3>Unable to load incidents</h3><p>Check Supabase permissions and migration setup.</p></div>';return}
 opsRows=(data||[]).filter(r=>!['resolved','closed','success'].includes(String(r.status||'').toLowerCase())).map(r=>({...r,_risk:riskFor(r)})).sort((a,b)=>b._risk-a._risk);
 q('#opsCritical').textContent=opsRows.filter(r=>r._risk>=70).length;
 q('#opsHigh').textContent=opsRows.filter(r=>r._risk>=40&&r._risk<70).length;
 q('#opsReview').textContent=opsRows.filter(r=>['under review','review'].includes(String(r.status||'').toLowerCase())).length;
 q('#opsOpen').textContent=opsRows.length;
 q('#opsQueue').innerHTML=opsRows.slice(0,15).map(r=>'<div class="resq-incident"><div class="resq-incident-top"><div><div class="resq-incident-title">'+esc(r.category||'Safety incident')+' · '+esc(r.location_text||'Location unavailable')+'</div><div class="resq-incident-meta">'+esc(r.reference_number||r.id||'')+' · '+time(r.created_at)+'<br>'+esc(String(r.description||'').slice(0,180))+'</div></div><span class="resq-pill '+level(r._risk)+'">'+r._risk+'/100 · '+level(r._risk).toUpperCase()+'</span></div><div class="resq-actions"><button class="btn btn-outline" data-open-incident="'+esc(r.id)+'">Open incident</button><button class="btn btn-outline" data-respond="'+esc(r.id)+'">Mark responding</button><button class="btn btn-outline" data-assign="'+esc(r.id)+'">Assign help</button><button class="btn btn-primary" data-resolve="'+esc(r.id)+'">Resolve</button></div></div>').join('')||'<div class="empty"><h3>No open incidents</h3><p>New active citizen reports will appear here.</p></div>';
 q('#opsQueue').querySelectorAll('[data-open-incident]').forEach(b=>b.onclick=()=>detail(b.dataset.openIncident));
 q('#opsQueue').querySelectorAll('[data-respond]').forEach(b=>b.onclick=()=>changeStatus(b.dataset.respond,'Under review'));
 q('#opsQueue').querySelectorAll('[data-assign]').forEach(b=>b.onclick=()=>assignHelp(b.dataset.assign));
 q('#opsQueue').querySelectorAll('[data-resolve]').forEach(b=>b.onclick=()=>changeStatus(b.dataset.resolve,'Resolved'));
 const oa=await official(); const top=opsRows[0];
 q('#opsBrief').textContent=top?('Highest priority: '+(top.category||'incident')+' near '+(top.location_text||'unknown area')+'. Risk is '+top._risk+'/100. '+(oa.length?'There are '+oa.length+' official safety signals available for verification. ':'No official signal was returned by the source endpoint. ')+'Verify conditions before public escalation.'): 'No active incident currently requires operational attention.';
 if(top)renderFactors(top);
 st.textContent='Live · '+new Date().toLocaleTimeString();
 if(window.lucide)lucide.createIcons();
}
function renderFactors(r){q('#opsFactors').innerHTML=factors(r).map(f=>'<div class="resq-factor"><span>'+esc(f.name)+'</span><strong>+'+f.value+'</strong></div>').join('')+'<div class="resq-factor"><span><b>Total decision-support context</b></span><strong>'+r._risk+'/100</strong></div>'}
async function audit(id,action,oldv,newv){
 try{await supabaseClient.from('resq_audit_log').insert({entity_type:'incident',entity_id:String(id),action,old_value:oldv||{},new_value:newv||{},actor_user_id:demoUser.id})}catch(e){console.warn('Audit unavailable',e)}
}
async function assignHelp(id){
 const row=opsRows.find(x=>String(x.id)===String(id));if(!row)return;
 const name=prompt('Who is being assigned? Enter responder, volunteer or team name:');if(!name)return;
 const type=prompt('Help type? Example: medical, rescue, road clearance, volunteer:','response');
 try{
  const {error}=await supabaseClient.from('resq_incident_assignments').insert({incident_id:String(id),incident_reference:row.reference_number||null,assignee_name:name,resource_type:type||'response',status:'assigned',assigned_by:demoUser.id,notes:'Assigned from Response Board'});
  if(error)throw error;
  await audit(id,'response_assigned',{}, {assignee:name,resource_type:type||'response'});
  await supabaseClient.from('resq_incident_actions').insert({incident_id:String(id),incident_reference:row.reference_number||null,action_type:'assignment',action_text:'Assigned '+name+' for '+(type||'response'),actor_user_id:demoUser.id,metadata:{assignee:name,resource_type:type||'response'}});
  toast?.('Response assignment recorded');detail(id);
 }catch(e){console.error(e);toast?.('Assignment failed. Run the 10/10 Supabase migration first.')}
}
async function changeStatus(id,status){
 const row=opsRows.find(x=>String(x.id)===String(id));if(!row)return;
 const {error}=await supabaseClient.from('live_incident_reports').update({status}).eq('id',id);
 if(error){toast?.('Could not update incident');return}
 await audit(id,'status_changed',{status:row.status},{status});
 try{await supabaseClient.from('resq_incident_actions').insert({incident_id:String(id),incident_reference:row.reference_number,action_type:'status_change',action_text:'Status changed to '+status,actor_user_id:demoUser.id,metadata:{from:row.status,to:status}})}catch(_){}
 toast?.('Incident updated: '+status);loadOps();
}
async function detail(id){
 const r=opsRows.find(x=>String(x.id)===String(id));if(!r)return;
 let timeline=[];
 try{const c=await supabaseClient.from('resq_ai_incident_clusters').select('id,location_label,hazard_type,confidence,report_count').ilike('location_label','%'+String(r.location_text||'').split(',')[0]+'%').limit(1);const cid=c.data?.[0]?.id;if(cid){const t=await supabaseClient.from('resq_ai_timeline').select('event_type,event_text,source_type,created_at').eq('cluster_id',cid).order('created_at',{ascending:true}).limit(30);timeline=t.data||[]}}catch(_){}
 const modal=document.createElement('div');modal.className='resq-modal show';modal.innerHTML='<div class="resq-modal-box"><div class="resq-ops-card-head"><div><div class="eyebrow">Incident detail</div><h2>'+esc(r.category||'Safety incident')+' · '+esc(r.location_text||'Unknown location')+'</h2><div class="resq-small">'+esc(r.reference_number||r.id)+' · '+time(r.created_at)+'</div></div><button class="btn btn-outline" id="resqClose">Close</button></div><div class="resq-brief"><b>Risk '+r._risk+'/100</b> · '+level(r._risk).toUpperCase()+'<br>'+esc(r.description||'No description supplied.')+'</div><h3 style="margin:18px 0 8px">Incident timeline</h3><div class="resq-timeline">'+(timeline.length?timeline.map(t=>'<div class="resq-tl"><b>'+esc(t.event_type||'event')+'</b> — '+esc(t.event_text||'')+'<div class="resq-small">'+time(t.created_at)+' · '+esc(t.source_type||'system')+'</div></div>').join(''):'<div class="resq-small">No persisted timeline events yet. The incident can still be acted on from the response board.</div>')+'</div><h3 style="margin:18px 0 8px">Explainable risk</h3><div>'+factors(r).map(f=>'<div class="resq-factor"><span>'+esc(f.name)+'</span><strong>+'+f.value+'</strong></div>').join('')+'</div><div class="resq-actions" style="margin-top:16px"><button class="btn btn-outline" id="resqRespond">Mark responding</button><button class="btn btn-primary" id="resqResolve">Resolve incident</button></div></div>';
 document.body.appendChild(modal);modal.querySelector('#resqClose').onclick=()=>modal.remove();modal.addEventListener('click',e=>{if(e.target===modal)modal.remove()});modal.querySelector('#resqRespond').onclick=async()=>{modal.remove();await changeStatus(id,'Under review')};modal.querySelector('#resqResolve').onclick=async()=>{modal.remove();await changeStatus(id,'Resolved')};
}
function openOps(){showPage();loadOps();if(window.lucide)lucide.createIcons()}
function install(){
 ensureStyles();ensureNav();ensurePage();
 const baseGo=window.go;
 window.go=function(page){
   if(page==='ops'){if(demoUser?.role!=='admin'){toast?.('Admin sign-in is required');return}openOps();return}
   if(q('#resqOpsPage'))q('#resqOpsPage').style.display='none';
   return baseGo.apply(this,arguments);
 };
 const oldSync=window.syncRole;
 if(typeof oldSync==='function'){
   window.syncRole=function(){const out=oldSync.apply(this,arguments);ensureNav();
 const syncOpsNav=()=>{const b=q('#resqOpsNav');if(b)b.hidden=!(typeof demoUser!=='undefined'&&demoUser?.role==='admin');};
 syncOpsNav();
 setInterval(syncOpsNav,1000);return out}
 }
 ensureNav();const b=q('#resqOpsNav');if(b)b.hidden=demoUser?.role!=='admin';
 window.ResQ10X={openOps,loadOps,detail};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install);else install();
})();